<?php
declare(strict_types=1);
namespace Simplify\Panel\Filament\Admin\Pages;

use App\Models\Plugin;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Simplify\Panel\Services\PluginUpdater;

/** Simplify's plugin overview: status, versions and safe updates with rollback. Opens from Admin tools. */
final class ManagePlugins extends Page
{
    protected static ?string $title = 'Plugins';
    public function getTitle(): string|\Illuminate\Contracts\Support\Htmlable { return __(static::$title); }
    public static function getNavigationLabel(): string { return __(static::$title); }
    protected static ?string $slug = 'simplify-plugins';
    protected string $view = 'pelican-simplify::admin-plugins';
    protected static bool $shouldRegisterNavigation = false;

    public static function canAccess(): bool { return (bool) user()?->can('viewAny', Plugin::class) && \Simplify\Panel\Services\FeatureSettings::enabled('plugin_manager'); }

    private function canChange(Plugin $plugin): bool { return (bool) user()?->can('update', $plugin); }

    /** True while an update, install or uninstall started here is running; the page reloads once it is done. */
    public bool $busy = false;

    /** Rows for the view; update lookups are cached for 50 seconds. */
    public function plugins(): array
    {
        Plugin::refreshRows();
        $rows = Plugin::query()->orderBy('load_order')->orderBy('name')->get()->map(function (Plugin $plugin): array {
            $latest = $plugin->status->value === 'not_installed' ? null : PluginUpdater::latestVersion($plugin);
            return [
                'id' => $plugin->id,
                'name' => $plugin->name,
                'author' => $plugin->author,
                'description' => $plugin->description,
                'version' => $plugin->version,
                'latest' => $latest && version_compare($latest, $plugin->version, '>') ? $latest : null,
                'status' => $plugin->status->value,
                'message' => $plugin->status_message,
                'can_change' => $this->canChange($plugin),
                'can_delete' => (bool) user()?->can('delete', $plugin),
                'updating' => \Illuminate\Support\Facades\Cache::has('simplify.plugin-update-queued.'.$plugin->id),
                'busy_since' => \Illuminate\Support\Facades\Cache::get('simplify.plugin-queued.'.$plugin->id),
            ];
        })->all();
        $busy = collect($rows)->contains(fn (array $row) => $row['updating'] || $row['busy_since']);
        // New plugin code only takes effect on a fresh page load.
        if ($this->busy && !$busy) $this->js('window.location.reload()');
        $this->busy = $busy;
        return $rows;
    }

    /** Seconds since the scheduled update check last ran, or null when it never ran. */
    public function lastCheckAge(): ?int
    {
        $at = \Illuminate\Support\Facades\Cache::get('simplify.plugin-check-at');
        return is_int($at) ? max(0, time() - $at) : null;
    }

    public function updatePlugin(string $id): void
    {
        $plugin = Plugin::query()->findOrFail($id);
        abort_unless($this->canChange($plugin), 403);
        \Illuminate\Support\Facades\Cache::put('simplify.plugin-update-queued.'.$id, true, 1200);
        $this->busy = true;
        \Simplify\Panel\Jobs\UpdatePlugin::dispatchAfterResponse($plugin->id, (int) user()->id);
        Notification::make()->title(__('Update started'))->body(__(':name is updated in the background. You get a notification when it is done; if anything fails, the current version is restored.', ['name' => $plugin->name]))->info()->send();
    }

    public function setEnabled(string $id, bool $enabled): void
    {
        $plugin = Plugin::query()->findOrFail($id);
        abort_unless($this->canChange($plugin) && in_array($plugin->status->value, ['enabled', 'disabled'], true), 403);
        $service = app(\App\Services\Helpers\PluginService::class);
        $enabled ? $service->enablePlugin($plugin) : $service->disablePlugin($plugin);
        Notification::make()->title($plugin->name.($enabled ? ' enabled' : ' disabled'))->body(__('Reload the panel to apply the change.'))->success()->send();
    }

    /** Install, uninstall and delete run through Pelican's own jobs and service, so nothing needs the legacy page. */
    public function installPlugin(string $id): void
    {
        $plugin = Plugin::query()->findOrFail($id);
        abort_unless($this->canChange($plugin) && $plugin->status->value === 'not_installed', 403);
        \Illuminate\Support\Facades\Cache::put('simplify.plugin-queued.'.$id, now()->timestamp, 1800);
        $this->busy = true;
        \Simplify\Panel\Jobs\ChangePlugin::dispatchAfterResponse($plugin->id, 'install', (int) user()->id);
        Notification::make()->title(__('Install started'))->body(__(':name is installed in the background. You get a notification when it is done.', ['name' => $plugin->name]))->info()->send();
    }

    public function uninstallPlugin(string $id): void
    {
        $plugin = Plugin::query()->findOrFail($id);
        abort_unless($this->canChange($plugin) && !in_array($plugin->status->value, ['not_installed', 'errored'], true), 403);
        \Illuminate\Support\Facades\Cache::put('simplify.plugin-queued.'.$id, now()->timestamp, 1800);
        $this->busy = true;
        \Simplify\Panel\Jobs\ChangePlugin::dispatchAfterResponse($plugin->id, 'uninstall', (int) user()->id);
        Notification::make()->title(__('Uninstall started'))->body(__(':name is removed in the background. Its files stay until you delete it.', ['name' => $plugin->name]))->info()->send();
    }

    public function deletePlugin(string $id): void
    {
        $plugin = Plugin::query()->findOrFail($id);
        abort_unless(user()?->can('delete', $plugin) && in_array($plugin->status->value, ['not_installed', 'errored'], true), 403);
        app(\App\Services\Helpers\PluginService::class)->deletePlugin($plugin);
        Notification::make()->title(__(':name deleted', ['name' => $plugin->name]))->success()->send();
    }

    protected function getHeaderActions(): array
    {
        $import = fn (callable $download) => function (array $data) use ($download): void {
            try {
                $download(app(\App\Services\Helpers\PluginService::class), $data);
                Notification::make()->title(__('Plugin imported'))->body(__('Install it from the list to start using it.'))->success()->send();
            } catch (\Throwable $exception) {
                report($exception);
                Notification::make()->title(__('Import failed'))->body($exception->getMessage())->danger()->send();
            }
        };
        return [
            \Filament\Actions\Action::make('checkUpdates')->label(__('Check for updates'))->tooltip(__('Check for updates now'))->icon('tabler-refresh')
                ->action(function (): void {
                    \Simplify\Panel\Services\UpdateCheck::forget();
                    $count = count(PluginUpdater::available(true));
                    Notification::make()->title($count ? trans_choice(':count update available|:count updates available', $count, ['count' => $count]) : __('Everything is up to date'))->success()->send();
                }),
            \Filament\Actions\Action::make('importUrl')->label(__('Import from URL'))->tooltip(__('Import from URL'))->icon('tabler-world-download')
                ->authorize(fn () => user()?->can('create', Plugin::class))
                ->schema([\Filament\Forms\Components\TextInput::make('url')->label(__('Zip URL'))->required()->url()->endsWith('.zip')])
                ->action($import(fn ($service, array $data) => $service->downloadPluginFromUrl($data['url']))),
            \Filament\Actions\Action::make('importFile')->label(__('Upload zip'))->tooltip(__('Upload zip'))->icon('tabler-file-upload')
                ->authorize(fn () => user()?->can('create', Plugin::class))
                ->schema([\Filament\Forms\Components\FileUpload::make('file')->label(__('Plugin zip'))->required()
                    ->acceptedFileTypes(['application/zip', 'application/zip-compressed', 'application/x-zip-compressed'])
                    ->preserveFilenames()->previewable(false)->storeFiles(false)])
                ->action($import(fn ($service, array $data) => $service->downloadPluginFromFile($data['file']))),
        ];
    }
}
