<?php
namespace Simplify\Panel\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Simplify\Panel\Filament\App\Pages\Dashboard;
final class Home
{
    public function handle(Request $r,Closure $next): mixed
    {
        if (\Simplify\Panel\Services\FeatureSettings::enabled('dashboard') && !($r->boolean('simplify_legacy') && (user()?->isAdmin()||\Simplify\Panel\Services\FeatureSettings::enabled('user_legacy'))) && $r->isMethod('GET') && $r->route()?->getName()==='filament.app.resources.servers.index' && user()) return redirect(Dashboard::getUrl(panel:'app'));
        return $next($r);
    }
}
