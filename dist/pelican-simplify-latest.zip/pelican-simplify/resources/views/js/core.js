/* Simplify core runtime, loaded on every panel page (and inside embedded workspaces).
   1. Theme: light/dark preference, accent colour and the embedded-workspace marker, applied before paint.
   2. UI: tooltips, toasts, confirm/prompt dialogs and a notice history, all in the Simplify style.
   Embedded pages forward toasts and dialogs to the dashboard so they cover the whole screen. */
(() => {
  if (window.SimplifyTheme) {
    window.SimplifyTheme.configure(window.simplifyThemeConfig || {});
    return;
  }
  const root = document.documentElement;
  const KEY = 'pelicanSimplify.theme';
  const CHOICES = ['light', 'dark', 'system'];
  const media = matchMedia('(prefers-color-scheme: dark)');
  let options = window.simplifyThemeConfig || {};
  let preference = 'system';
  try {
    const saved = localStorage.getItem(KEY);
    if (CHOICES.includes(saved)) preference = saved;
  } catch {}

  // An embedded workspace learns its kind and accent from its own <iframe> element.
  let frameKind = '';
  let frameAccent = '';
  try {
    const host = window.frameElement;
    if (host?.dataset?.psFrame) {
      frameKind = host.dataset.psFrame;
      frameAccent = host.dataset.psAccent || '';
    }
  } catch {}

  const dark = () => preference === 'dark' || (preference === 'system' && media.matches);
  const hex = (value) => (/^#[0-9a-f]{6}$/i.test(value || '') ? value : '');
  const accentInk = (color) => {
    const [r, g, b] = color.slice(1).match(/../g).map((v) => {
      const x = parseInt(v, 16) / 255;
      return x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
    });
    return r * 0.2126 + g * 0.7152 + b * 0.0722 > 0.179 ? '#111118' : '#ffffff';
  };

  const apply = () => {
    const ownPage = !frameKind && !options.legacy_page;
    const themed = !!options.global_theme && (frameKind ? !!options.legacy_theme || ['create', 'settings'].includes(frameKind) : ownPage);
    root.classList.toggle('ps-theme', themed);
    if (themed || ownPage) root.classList.toggle('dark', dark());
    const accent = hex(frameAccent) || hex(options.accent_color);
    if (accent) {
      root.style.setProperty('--ps-accent', accent);
      root.style.setProperty('--ps-on-accent', accentInk(accent));
    }
    root.classList.toggle('ps-console-dark', !!options.console_dark);
    root.classList.toggle('ps-console-adaptive', !options.console_dark);
    if (frameKind) {
      root.classList.add('ps-frame');
      root.dataset.psFrame = frameKind;
    }
    ui.layer?.classList.toggle('dark', dark());
    window.dispatchEvent(new CustomEvent('simplify:theme', { detail: { preference, dark: dark() } }));
  };

  window.SimplifyTheme = {
    accentInk,
    dark,
    preference: () => preference,
    set(value) {
      if (!CHOICES.includes(value)) return;
      preference = value;
      try {
        localStorage.setItem(KEY, value);
        localStorage.setItem('theme', value);
      } catch {}
      apply();
    },
    /** Keeps an already loaded workspace in step with the dashboard (theme and accent). */
    frame(frame, kind, accent) {
      if (!frame) return;
      if (kind) frame.dataset.psFrame = kind;
      if (accent) frame.dataset.psAccent = accent;
      try {
        frame.contentWindow?.SimplifyTheme?.sync(preference, frame.dataset.psAccent || '');
      } catch {}
    },
    sync(value, accent) {
      if (CHOICES.includes(value)) preference = value;
      if (hex(accent)) frameAccent = accent;
      apply();
    },
    configure(value) {
      options = value || {};
      apply();
    },
  };

  media.addEventListener('change', () => preference === 'system' && apply());
  window.addEventListener('storage', (event) => {
    if (event.key === KEY && CHOICES.includes(event.newValue)) {
      preference = event.newValue;
      apply();
    }
  });
  // Filament's own theme switcher dispatches this event.
  window.addEventListener('theme-changed', (event) => {
    const value = event.detail?.theme ?? event.detail;
    if (CHOICES.includes(value) && value !== preference) window.SimplifyTheme.set(value);
  });
  document.addEventListener('livewire:navigated', () => window.SimplifyTheme.configure(window.simplifyThemeConfig || options));

  /* UI runtime ------------------------------------------------------------------------------ */
  const ui = { layer: null, tooltip: null, toasts: null, history: [], tipTarget: null, tipTimer: 0, dialogs: 0 };
  const icon = (name) => {
    const paths = {
      info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 8v5m0-9h.01',
      ok: 'm5 12 4 4 10-10',
      warn: 'M12 3 2 21h20Zm0 7v5m0 3h.01',
      danger: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm-3 6 6 6m0-6-6 6',
      close: 'm6 6 12 12M18 6 6 18',
    };
    return '<svg class="ps-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="' + (paths[name] || paths.info) + '"/></svg>';
  };
  const parentUi = () => {
    try {
      if (window.parent !== window && window.parent.Simplify?.ui === true) return window.parent.Simplify;
    } catch {}
    return null;
  };
  // Dialogs open inside the active popup (if any) so its focus trap keeps working.
  const mountPoint = () => {
    const open = [...document.querySelectorAll('[aria-modal="true"]')].filter((el) => el.getClientRects().length);
    return open[open.length - 1] || layer();
  };
  const layer = () => {
    if (ui.layer?.isConnected) return ui.layer;
    ui.layer = document.createElement('div');
    ui.layer.className = 'ps-ui' + (dark() ? ' dark' : '');
    ui.layer.style.setProperty('--ps-accent', getComputedStyle(root).getPropertyValue('--ps-accent').trim() || '#878787');
    document.body.append(ui.layer);
    return ui.layer;
  };

  // Tooltips: every [data-tip] element; stray title attributes inside Simplify become tooltips too.
  const TIP_SCOPE = '.ps, .ps-ui, .ssc-wizard, .ps-settings-page, .ps-legacy-return';
  const placeTip = (target) => {
    const tip = ui.tooltip;
    const box = target.getBoundingClientRect();
    const own = tip.getBoundingClientRect();
    let top = box.bottom + 8;
    if (top + own.height > innerHeight - 8) top = box.top - own.height - 8;
    const left = Math.min(Math.max(8, box.left + box.width / 2 - own.width / 2), innerWidth - own.width - 8);
    tip.style.transform = `translate(${Math.round(left)}px, ${Math.round(Math.max(8, top))}px)`;
  };
  const showTip = (target) => {
    const text = target.getAttribute('data-tip');
    if (!text || !target.isConnected) return;
    if (!ui.tooltip) {
      ui.tooltip = document.createElement('div');
      ui.tooltip.className = 'ps-tooltip';
      ui.tooltip.setAttribute('role', 'tooltip');
      ui.tooltip.id = 'ps-tooltip';
      layer().append(ui.tooltip);
    }
    const label = target.getAttribute('data-tip-label');
    ui.tooltip.replaceChildren();
    if (label) {
      const small = document.createElement('small');
      small.textContent = label;
      ui.tooltip.append(small);
    }
    ui.tooltip.append(document.createTextNode(text));
    ui.tooltip.classList.add('is-visible');
    target.setAttribute('aria-describedby', 'ps-tooltip');
    placeTip(target);
  };
  const hideTip = () => {
    clearTimeout(ui.tipTimer);
    ui.tipTarget?.removeAttribute('aria-describedby');
    ui.tipTarget = null;
    ui.tooltip?.classList.remove('is-visible');
  };
  const tipTargetOf = (node) => {
    if (!(node instanceof Element)) return null;
    const titled = node.closest('[title]');
    if (titled && !titled.matches('iframe, svg, title') && titled.closest(TIP_SCOPE)) {
      titled.setAttribute('data-tip', titled.getAttribute('title'));
      titled.removeAttribute('title');
    }
    return node.closest('[data-tip]');
  };
  const enterTip = (event, delay) => {
    const target = tipTargetOf(event.target);
    if (target === ui.tipTarget) return;
    hideTip();
    if (!target) return;
    ui.tipTarget = target;
    ui.tipTimer = setTimeout(() => showTip(target), delay);
  };
  document.addEventListener('pointerover', (event) => event.pointerType !== 'touch' && enterTip(event, 350), { passive: true });
  document.addEventListener('focusin', (event) => enterTip(event, 0));
  document.addEventListener('pointerout', (event) => {
    if (ui.tipTarget && !ui.tipTarget.contains(event.relatedTarget)) hideTip();
  }, { passive: true });
  document.addEventListener('focusout', hideTip);
  document.addEventListener('pointerdown', hideTip, { passive: true });
  window.addEventListener('scroll', hideTip, { passive: true, capture: true });
  document.addEventListener('keydown', (event) => event.key === 'Escape' && hideTip());

  const toast = (message, tone = 'info', duration) => {
    const text = String(message ?? '').trim();
    if (!text) return;
    const parent = parentUi();
    if (parent) return parent.toast(text, tone, duration);
    tone = ['ok', 'warn', 'danger', 'info'].includes(tone) ? tone : 'info';
    if (!ui.toasts?.isConnected) {
      ui.toasts = document.createElement('div');
      ui.toasts.className = 'ps-toasts';
      ui.toasts.setAttribute('role', 'status');
      ui.toasts.setAttribute('aria-live', 'polite');
      layer().append(ui.toasts);
    }
    const node = document.createElement('div');
    node.className = 'ps-toast is-' + tone;
    node.innerHTML = icon(tone) + '<span></span><button type="button" aria-label="Dismiss">' + icon('close') + '</button>';
    node.querySelector('span').textContent = text;
    const remove = () => node.remove();
    node.querySelector('button').addEventListener('click', remove);
    ui.toasts.append(node);
    while (ui.toasts.children.length > 3) ui.toasts.firstElementChild.remove();
    setTimeout(remove, duration || (tone === 'danger' ? 10000 : 6500));
    const entry = { id: Date.now() + Math.random(), text, tone, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    ui.history = [entry, ...ui.history].slice(0, 20);
    window.dispatchEvent(new CustomEvent('simplify:notice', { detail: entry }));
  };

  /**
   * A Simplify confirmation dialog. Resolves to true/false, or to the typed text when `input` is set.
   * Options: title, message, confirmLabel, cancelLabel, tone ('danger' | 'primary'), input, placeholder, requireText.
   */
  const dialog = (opts = {}) => {
    const parent = parentUi();
    if (parent) return parent.confirm(opts);
    return new Promise((resolve) => {
      const previous = document.activeElement;
      const wrap = document.createElement('div');
      wrap.className = 'ps-modal-layer';
      wrap.dataset.open = 'true';
      wrap.innerHTML =
        '<section class="ps-modal is-sm" role="alertdialog" aria-modal="true" aria-labelledby="ps-dialog-title">' +
        '<header class="ps-modal-head"><h2 id="ps-dialog-title"></h2></header>' +
        '<div class="ps-modal-body"><p class="ps-help" data-message></p></div>' +
        '<footer class="ps-modal-foot"><button type="button" class="ps-btn" data-cancel></button><button type="button" class="ps-btn" data-confirm></button></footer>' +
        '</section>';
      wrap.querySelector('h2').textContent = opts.title || 'Are you sure?';
      const message = wrap.querySelector('[data-message]');
      if (opts.message) message.textContent = opts.message;
      else message.remove();
      const cancel = wrap.querySelector('[data-cancel]');
      const confirm = wrap.querySelector('[data-confirm]');
      cancel.textContent = opts.cancelLabel || 'Cancel';
      confirm.textContent = opts.confirmLabel || 'Confirm';
      confirm.classList.add(opts.tone === 'danger' ? 'is-danger' : 'is-primary');
      let field = null;
      if (opts.input || opts.requireText) {
        const label = document.createElement('label');
        label.className = 'ps-field';
        label.textContent = opts.inputLabel || (opts.requireText ? 'Type “' + opts.requireText + '” to confirm' : '');
        field = document.createElement('input');
        field.placeholder = opts.placeholder || opts.requireText || '';
        field.autocomplete = 'off';
        label.append(field);
        wrap.querySelector('.ps-modal-body').append(label);
        const check = () => (confirm.disabled = !!opts.requireText && field.value !== opts.requireText);
        field.addEventListener('input', check);
        check();
      }
      const finish = (value) => {
        wrap.remove();
        ui.dialogs--;
        if (!ui.dialogs) root.classList.remove('ps-ui-locked');
        try { previous?.focus?.(); } catch {}
        resolve(value);
      };
      cancel.addEventListener('click', () => finish(field ? null : false));
      confirm.addEventListener('click', () => !confirm.disabled && finish(field ? field.value : true));
      wrap.addEventListener('click', (event) => event.target === wrap && finish(field ? null : false));
      wrap.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') { event.stopPropagation(); finish(field ? null : false); }
        if (event.key === 'Enter' && event.target === field && !confirm.disabled) finish(field.value);
        if (event.key === 'Tab') {
          const items = [...wrap.querySelectorAll('button:not(:disabled), input')];
          const index = items.indexOf(document.activeElement);
          const next = items[(index + (event.shiftKey ? -1 : 1) + items.length) % items.length];
          event.preventDefault();
          next?.focus();
        }
      });
      ui.dialogs++;
      root.classList.add('ps-ui-locked');
      const host = mountPoint();
      if (host !== ui.layer && !host.closest('.ps')) wrap.classList.toggle('dark', dark());
      host.append(wrap);
      (field || confirm).focus();
    });
  };

  window.Simplify = {
    ui: true,
    toast,
    confirm: dialog,
    prompt: (opts) => dialog({ ...opts, input: true }),
    history: () => ui.history.slice(),
    hideTooltip: hideTip,
  };
  apply();
})();
